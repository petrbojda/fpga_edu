Console command files for reference design root directory only.  It doesn't work to execute files on "<design root directory>/console/<type>/"
Execute "_create_win_setup.cmd /_create_linux_setup.sh" from root directory and follow console menu to copy need files into the root directory!
